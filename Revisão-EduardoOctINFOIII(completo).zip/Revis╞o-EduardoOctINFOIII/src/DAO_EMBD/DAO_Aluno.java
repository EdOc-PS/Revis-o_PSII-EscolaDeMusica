package DAO_EMBD;

import Conexao_EMBD.ConexaoBD;
import Modelo_EMBD.Modelo_Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAO_Aluno {
   public boolean InserirAluno (Modelo_Aluno DBD){
        try {
            String SQL = "INSERT INTO eduardo_octavio_escolamusica.ALUNO (nomea, cpfa, telefonea, emaila, datadenasca, gostoinstrumental) "
                    + "VALUES (?,?,?,?,?,?)";
            Connection ConexaoEMBD = ConexaoBD.getConexao();
              PreparedStatement comando = ConexaoEMBD.prepareStatement(SQL);
             
             comando.setString(1, DBD.getNomea());
              comando.setString(2, DBD.getCpfa());
               comando.setInt(3, DBD.getTelefonea());
               comando.setString(4, DBD.getEmaila());
                comando.setString(5, DBD.getDatadenasca());
                  comando.setString(6, DBD.getGostoinstrumental());
                  
             int retornar = comando.executeUpdate();
               if (retornar > 0){
                   return true;
                }
                
                
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Aluno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
   }
    public List<Modelo_Aluno> LUCA(){
        try {
            String SQL = "SELECT nomea, cpfa, telefonea, gostoinstrumental, emaila, datadenasca FROM eduardo_octavio_escolamusica.ALUNO ORDER BY nomea";
            List<Modelo_Aluno> ListaU = new ArrayList<Modelo_Aluno>();
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL);
            ResultSet Resul = PS.executeQuery();
            
            while (Resul.next()){
               Modelo_Aluno MUD = new Modelo_Aluno();
                MUD = this.PeDU(Resul);
                ListaU.add(MUD);
            }
            return ListaU;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Aluno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    private Modelo_Aluno PeDU(ResultSet Resul){
        try {
            Modelo_Aluno MUD = new Modelo_Aluno();
            MUD.setNomea(Resul.getString("nomea"));
            MUD.setCpfa(Resul.getString("cpfa"));
            MUD.setTelefonea(Resul.getInt("telefonea"));
            MUD.setGostoinstrumental(Resul.getString("gostoinstrumental"));
            MUD.setEmaila(Resul.getString("emaila"));
            MUD.setDatadenasca(Resul.getString("datadenasca"));
            return MUD;
            
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Aluno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public Modelo_Aluno ConsultaA(Modelo_Aluno DDados){
        try {
            String SQL = "SELECT * FROM eduardo_octavio_escolamusica.ALUNO";
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            String Filtro ="";
            
            if(DDados != null && DDados.getNomea()!= null && !DDados.getNomea().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND nomea ilike '%"+DDados.getNomea()+"%'";
                }
                else{
                Filtro = " WHERE nomea ilike '%" + DDados.getNomea() +"%'";
                }
            }
            if(DDados != null && DDados.getCpfa()!= null && !DDados.getCpfa().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND cpfa ilike '%"+DDados.getCpfa()+"%'";
                }
                else{
                Filtro = " WHERE cpfa ilike '%" + DDados.getCpfa()+"%'";
                }
            }
              if(DDados != null && DDados.getTelefonea()>0){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " WHERE telefonea '%"+DDados.getTelefonea()+"%'";
                }
                
            } 
             if(DDados != null && DDados.getEmaila()!= null && !DDados.getEmaila().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND emaila = '"+DDados.getEmaila()+"'";
                }
                else{
                Filtro = " WHERE emaila = '" + DDados.getEmaila() + "'";
                }
            }
              if(DDados != null && DDados.getDatadenasca()!= null && !DDados.getDatadenasca().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND datadenasca ilike '%"+DDados.getDatadenasca()+"%'";
                }
                else{
                Filtro = " WHERE datadenasca ilike '%" + DDados.getDatadenasca()+"%'";
                }
            }
               if(DDados != null && DDados.getGostoinstrumental()!= null && !DDados.getGostoinstrumental().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND gostoinstrumental ilike '%"+DDados.getGostoinstrumental()+"%'";
                }
                else{
                Filtro = " WHERE gostoinstrumental ilike '%" + DDados.getGostoinstrumental()+"%'";
                }
            }
           
                
             
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL + Filtro);         
            ResultSet Resul = PS.executeQuery();
            
            if(Resul.next()){
               Modelo_Aluno MUD = new Modelo_Aluno();
                MUD = this.PeDU(Resul);
                return MUD;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Aluno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public Modelo_Aluno ConsultaA(String cpfa){
         try {
            String SQL = "SELECT *  FROM eduardo_octavio_escolamusica.ALUNO WHERE cpfa = ?";
            
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL);
            PS.setString(1, String.valueOf(cpfa));
            ResultSet Resul = PS.executeQuery();
            
           if (Resul.next()){
                Modelo_Aluno MUD = new Modelo_Aluno();
                MUD= this.PeDU(Resul);
                return MUD;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Aluno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
     
    }
     public boolean ATUA(Modelo_Aluno DadosDIS){
        try {
            String SQL = "UPDATE eduardo_octavio_escolamusica.ALUNO SET nomea = ?, telefonea = ?, emaila = ?, datadenasca = ?, gostoinstrumental = ? WHERE cpfa = ?";
            Connection ConexaoEMBD = ConexaoBD.getConexao();
              PreparedStatement comando = ConexaoEMBD.prepareStatement(SQL);
             
             comando.setString(1, DadosDIS.getNomea());
              comando.setString(6, DadosDIS.getCpfa());
               comando.setInt(2, DadosDIS.getTelefonea());
                comando.setString(3, DadosDIS.getEmaila());
                 comando.setString(4, DadosDIS.getDatadenasca());
                  comando.setString(5, DadosDIS.getGostoinstrumental());
                 
                  
             int retornar = comando.executeUpdate();
         if (retornar > 0){
                   return true;
                }
                
                
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Aluno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
  }