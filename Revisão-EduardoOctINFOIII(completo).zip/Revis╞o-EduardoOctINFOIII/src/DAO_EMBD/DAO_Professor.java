
package DAO_EMBD;

import Conexao_EMBD.ConexaoBD;
import Modelo_EMBD.Modelo_Professor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author eeuar
 */

public class DAO_Professor {

   public boolean InserirProfessor (Modelo_Professor DBP){
        try {
            String SQL = "INSERT INTO eduardo_octavio_escolamusica.PROFESSOR (nomep, telefonep, cpfp, emailp, datadenascp, ctps) "
                    + "VALUES (?,?,?,?,?,?)";
            Connection ConexaoEMBD = ConexaoBD.getConexao();
              PreparedStatement comando = ConexaoEMBD.prepareStatement(SQL);
             
             comando.setString(1, DBP.getNomep());
              comando.setInt(2, DBP.getTelefonep());
               comando.setString(3, DBP.getCpfp());
                comando.setString(4, DBP.getEmailp());
                 comando.setString(5, DBP.getDatadenascp());
                  comando.setInt(6, DBP.getCtps());
                  
             int retornar = comando.executeUpdate();
               if (retornar > 0){
                   return true;
                }
                
                
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Professor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
   }
    public List<Modelo_Professor> LUCP(){
        try {
            String SQL = "SELECT nomep, cpfp, telefonep, emailp, datadenascp, ctps FROM eduardo_octavio_escolamusica.PROFESSOR ORDER BY nomep";
            List<Modelo_Professor> ListaU = new ArrayList<Modelo_Professor>();
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL);
            ResultSet Resul = PS.executeQuery();
            
            while (Resul.next()){
               Modelo_Professor MUP = new Modelo_Professor();
                MUP = this.PeDU(Resul);
                ListaU.add(MUP);
            }
            return ListaU;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Professor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    private Modelo_Professor PeDU(ResultSet Resul){
        try {
            Modelo_Professor MUP = new Modelo_Professor();
            MUP.setNomep(Resul.getString("nomep"));
            MUP.setCpfp(Resul.getString("cpfp"));
            MUP.setTelefonep(Resul.getInt("telefonep"));
            MUP.setEmailp(Resul.getString("emailp"));
            MUP.setDatadenascp(Resul.getString("datadenascp"));
            MUP.setCtps(Resul.getInt("ctps"));
       
            return MUP;
            
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Professor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public Modelo_Professor ConsultaP(Modelo_Professor DDados){
        try {
            String SQL = "SELECT * FROM eduardo_octavio_escolamusica.PROFESSOR";
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            String Filtro ="";
            
            if(DDados != null && DDados.getNomep()!= null && !DDados.getNomep().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND nomep ilike '%"+DDados.getNomep()+"%'";
                }
                else{
                Filtro = " WHERE nomep ilike '%" + DDados.getNomep() +"%'";
                }
            }
             if(DDados != null && DDados.getTelefonep()>0){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " WHERE telefonep '%"+DDados.getTelefonep()+"%'";
                }  
            } 
             
              if(DDados != null && DDados.getCpfp()!= null && !DDados.getCpfp().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND cpfp ilike '%"+DDados.getCpfp()+"%'";
                }
                else{
                Filtro = " WHERE cpfp ilike '%" + DDados.getCpfp() +"%'";
                }
             } 
             if(DDados != null && DDados.getEmailp()!= null && !DDados.getEmailp().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND emailp = '"+DDados.getEmailp()+"'";
                }
                else{
                Filtro = " WHERE emailp = '" + DDados.getEmailp() + "'";
                }
            }
              if(DDados != null && DDados.getDatadenascp()!= null && !DDados.getDatadenascp().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND datadenascp ilike '%"+DDados.getDatadenascp()+"%'";
                }
                else{
                Filtro = " WHERE datadenascp ilike '%" + DDados.getDatadenascp()+"%'";
                }
            }
            if(DDados != null && DDados.getCtps()>0){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " WHERE ctps '%"+DDados.getCtps()+"%'";
                }
                
            }             
             
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL + Filtro);         
            ResultSet Resul = PS.executeQuery();
            
            if(Resul.next()){
               Modelo_Professor MUP = new Modelo_Professor();
                MUP = this.PeDU(Resul);
                return MUP;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Professor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public Modelo_Professor ConsultaPI(String cpfp){
         try {
            String SQL = "SELECT * FROM eduardo_octavio_escolamusica.PROFESSOR WHERE cpfp = ?";
            
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL);
            PS.setString(1, cpfp);
            ResultSet Resul = PS.executeQuery();
            
           if (Resul.next()){
                Modelo_Professor MUP = new Modelo_Professor();
                MUP = this.PeDU(Resul);
                return MUP;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Professor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
     
    }
     public boolean ATUP(Modelo_Professor DadosDIS){
        try {
            String SQL = "UPDATE eduardo_octavio_escolamusica.PROFESSOR SET nomep = ?, telefonep = ?, emailp = ?, datadenascp = ?, ctps = ? WHERE cpfp = ?";
            Connection ConexaoEMBD = ConexaoBD.getConexao();
              PreparedStatement comando = ConexaoEMBD.prepareStatement(SQL);
             
             comando.setString(1, DadosDIS.getNomep());
              comando.setInt(2, DadosDIS.getTelefonep());
               comando.setString(6, DadosDIS.getCpfp());
                comando.setString(3, DadosDIS.getEmailp());
                 comando.setString(4, DadosDIS.getDatadenascp());
                  comando.setInt(5, DadosDIS.getCtps());
                 
                  
             int retornar = comando.executeUpdate();
         if (retornar > 0){
                   return true;
                }
                
                
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Professor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    }

