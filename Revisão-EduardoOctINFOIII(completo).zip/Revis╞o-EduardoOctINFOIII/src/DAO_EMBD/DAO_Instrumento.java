
package DAO_EMBD;

import Conexao_EMBD.ConexaoBD;
import Modelo_EMBD.Modelo_Instrumento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author eeuar
 */
public class DAO_Instrumento {
    public boolean InserirInstrumento (Modelo_Instrumento DBI){
        try {
            String SQL = "INSERT INTO eduardo_octavio_escolamusica.INSTRUMENTO (nomei, classificacao) "
                    + "VALUES (?,?)";
            Connection ConexaoEMBD = ConexaoBD.getConexao();
              PreparedStatement comando = ConexaoEMBD.prepareStatement(SQL);
             
             comando.setString(1, DBI.getNomei());
              comando.setString(2, DBI.getClassificacao());
               
                  
             int retornar = comando.executeUpdate();
               if (retornar > 0){
                   return true;
                }
                
                
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Instrumento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
   }
    public List<Modelo_Instrumento> LUCI(){
        try {
            String SQL = "SELECT nomei, classificacao, codi FROM eduardo_octavio_escolamusica.INSTRUMENTO ORDER BY codi";
            List<Modelo_Instrumento> ListaU = new ArrayList<Modelo_Instrumento>();
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL);
            ResultSet Resul = PS.executeQuery();
            
            while (Resul.next()){
               Modelo_Instrumento MUI = new Modelo_Instrumento();
                MUI = this.PeDU(Resul);
                ListaU.add(MUI);
            }
            return ListaU;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Professor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    private Modelo_Instrumento PeDU(ResultSet Resul){
        try {
            Modelo_Instrumento MUI = new Modelo_Instrumento();
            MUI.setNomei(Resul.getString("nomei"));
            MUI.setClassificacao(Resul.getString("classificacao"));
            MUI.setCodi(Resul.getInt("codi"));
        
       
            return MUI;
            
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Instrumento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public Modelo_Instrumento ConsultaI(Modelo_Instrumento DDados){
        try {
            String SQL = "SELECT * FROM eduardo_octavio_escolamusica.INSTRUMENTO";
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            String Filtro ="";
            
            if(DDados != null && DDados.getNomei()!= null && !DDados.getNomei().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND nomei ilike '%"+DDados.getNomei()+"%'";
                }
                else{
                Filtro = " WHERE nomei ilike '%" + DDados.getNomei() +"%'";
                }
            }     
             
             if(DDados != null && DDados.getClassificacao()!= null && !DDados.getClassificacao().equalsIgnoreCase("")){
                if(!Filtro.equalsIgnoreCase("")){
                    Filtro += " AND classificacao = '"+DDados.getClassificacao()+"'";
                }
                else{
                Filtro = " WHERE classificacao = '" + DDados.getClassificacao() + "'";
                }
            }       
         
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL + Filtro);         
            ResultSet Resul = PS.executeQuery();
            
            if(Resul.next()){
               Modelo_Instrumento MUI = new Modelo_Instrumento();
                MUI = this.PeDU(Resul);
                return MUI;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Instrumento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public Modelo_Instrumento ConsultaIN(String codi){
         try {
            String SQL = "SELECT nomei, classificacao, codi FROM eduardo_octavio_escolamusica.INSTRUMENTO WHERE codi = ?";
            
            Connection ConexaoEMBD = ConexaoBD.getConexao();
            PreparedStatement PS = ConexaoEMBD.prepareStatement(SQL);
            PS.setInt(1, Integer.valueOf(codi));
            ResultSet Resul = PS.executeQuery();
            
           if (Resul.next()){
                Modelo_Instrumento MUI = new Modelo_Instrumento();
                MUI = this.PeDU(Resul);
                return MUI;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Instrumento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
     
    }
     public boolean ATUI (Modelo_Instrumento DadosIS){
        try {
            String SQL = "UPDATE eduardo_octavio_escolamusica.ALUNO SET nomep = ?, classificacao = ? WHERE codi = ?";
            Connection ConexaoLJBD = ConexaoBD.getConexao();
              PreparedStatement comando = ConexaoLJBD.prepareStatement(SQL);
             
             comando.setString(1, DadosIS.getNomei());
              comando.setString(2, DadosIS.getClassificacao());
                  comando.setInt(3, DadosIS.getCodi());
                 
                  
             int retornar = comando.executeUpdate();
         if (retornar > 0){
                   return true;
                }
                
                
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Instrumento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
