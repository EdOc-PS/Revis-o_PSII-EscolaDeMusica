
package Modelo_EMBD;

/**
 * @author eeuar
 */

public class Modelo_Professor {
    private String nomep;
    private String cpfp;
    private int telefonep;
    private String emailp;
    private String datadenascp;
    private int ctps;

    public Modelo_Professor(String nomep, String cpfp, int telefonep, int ctps, String emailp, String datadenascp ) {
        this.nomep = nomep;
        this.cpfp = cpfp;
        this.ctps = ctps;
        this.telefonep = telefonep;
        this.emailp = emailp;
        this.datadenascp = datadenascp;
     
    }

    public Modelo_Professor() {
        this.nomep = "";
        this.cpfp = "";
        this.telefonep = 0;
        this.emailp = "";
        this.datadenascp = "";
        this.ctps = 0;
    }
    
    public String getNomep() {
        return nomep;
    }

    public void setNomep(String nomep) {
        this.nomep = nomep;
    }

    public String getCpfp() {
        return cpfp;
    }

    public void setCpfp(String cpfp) {
        this.cpfp = cpfp;
    }

  
    public int getTelefonep() {
        return telefonep;
    }

    public void setTelefonep(int telefonep) {
        this.telefonep = telefonep;
    }

    public String getEmailp() {
        return emailp;
    }

    public void setEmailp(String emailp) {
        this.emailp = emailp;
    }

    public String getDatadenascp() {
        return datadenascp;
    }

    public void setDatadenascp(String datadenascp) {
        this.datadenascp = datadenascp;
    }

    public int getCtps() {
        return ctps;
    }

    public void setCtps(int ctps) {
        this.ctps = ctps;
    }


    
    @Override
    public String toString() {
        return "| " + nomep + " | " + cpfp + " | " + telefonep + " |";
    }
    
}
