
package Modelo_EMBD;

/**
 * @author eeuar
 */
public class Modelo_Instrumento {
    
    private String nomei;
    private String Classificacao;
    private int codi;
    

    public Modelo_Instrumento(String nomei, String Classificacao, int codi) {
        this.nomei = nomei;
        this.Classificacao = Classificacao;
        this.codi = codi;
        
    }
    
    public Modelo_Instrumento() {
        this.nomei = "";
        this.Classificacao = "";
        this.codi = 0;
    }
  
    public String getNomei() {
        return nomei;
    }

    public void setNomei(String nomei) {
        this.nomei = nomei;
    }

    public String getClassificacao() {
        return Classificacao;
    }

    public void setClassificacao(String Classificaçao) {
        this.Classificacao = Classificaçao;
    }

    public int getCodi() {
        return codi;
    }

    public void setCodi(int codi) {
        this.codi = codi;
    }
     
  
    @Override
    public String toString() {
        return "| " + codi + " | "+  nomei + " | " + Classificacao + " |";
    }

}
