
package Modelo_EMBD;

/**
 * @author eeuar
 */

public class Modelo_Aluno {
            private String nomea;
            private String cpfa;
            private int telefonea;
            private String emaila;
            private String datadenasca;
            private String gostoinstrumental;

    public Modelo_Aluno(String nomea, String cpfa, int telefonea, String emaila, String datadenasca, String gostoinstrumental) {
        this.nomea = nomea;
        this.cpfa = cpfa;
        this.telefonea = telefonea;
        this.emaila = emaila;
        this.datadenasca = datadenasca;
        this.gostoinstrumental = gostoinstrumental;
    }

     public Modelo_Aluno() {
        this.nomea = "";
        this.cpfa = "";
        this.telefonea = 0;
        this.emaila = "";
        this.datadenasca = "";
        this.gostoinstrumental = "";
    }
   
    public String getNomea() {
        return nomea;
    }

    public void setNomea(String nomea) {
        this.nomea = nomea;
    }

    public String getCpfa() {
        return cpfa;
    }

    public void setCpfa(String cpfa) {
        this.cpfa = cpfa;
    }

 

    public int getTelefonea() {
        return telefonea;
    }

    public void setTelefonea(int telefonea) {
        this.telefonea = telefonea;
    }

    public String getEmaila() {
        return emaila;
    }

    public void setEmaila(String emaila) {
        this.emaila = emaila;
    }

    public String getDatadenasca() {
        return datadenasca;
    }

    public void setDatadenasca(String datadenasca) {
        this.datadenasca = datadenasca;
    }

    public String getGostoinstrumental() {
        return gostoinstrumental;
    }

    public void setGostoinstrumental(String gostoinstrumental) {
        this.gostoinstrumental = gostoinstrumental;
    }
    @Override
    public String toString() {
        return "| " + nomea + "| " + cpfa + " | " + telefonea + " | " + gostoinstrumental + " |";
    }
   
}
